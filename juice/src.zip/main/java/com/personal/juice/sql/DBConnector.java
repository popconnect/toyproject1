package com.personal.juice.sql;

import java.sql.*;

public class DBConnector {
    private Connection conn;
    
    public DBConnector() {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/toyproject", "toyproject", "toyprojectpw");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public ResultSet getTypeData() throws SQLException {
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT DISTINCT type FROM beverages");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (stmt != null) {stmt.close();}
        }
        return rs;
    }
}
